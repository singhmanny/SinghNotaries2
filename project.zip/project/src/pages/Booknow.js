/*import React from "react";
import { Link } from "react-router-dom";
import ApiCalendar from "react-google-calendar-api";

class Booknow extends React.Component {
    componentDidMount() {
        window.scrollTo(0, 0);
    }
    responseGoogle = (response) => {
      console.log(response);
    }
    render() {
        return (
            <div>
                <h1>Contact Page</h1>
                <p>This is the contact page</p>
                <GoogleLogin
                  clientId="1052543905785-tpuu9bh5gb8ipqbjlvmndbg8e39u9na1.apps.googleusercontent.com"
                  buttonText="Login"
                  onSuccess={this.responseGoogle}
                  onFailure={this.responseGoogle}
                  cookiePolicy={'single_host_origin'}
                />
                <Link to="/">Go to Home</Link>
            </div>
        );
    }
}

export default Booknow;



const config = {
  clientId: "<CLIENT_ID>",
  apiKey: "<API_KEY>",
  scope: "https://www.googleapis.com/auth/calendar",
  discoveryDocs: [
    "https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest",
  ],
};

const apiCalendar = new ApiCalendar(config);
*/