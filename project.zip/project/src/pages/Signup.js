/*
import React from "react";
import { Link } from "react-router-dom";

class Signup extends React.Component {
    render() {
        return (
            <div id="page-wrapper">
                <section id="main" className="container medium">
                    <header>
                        <h2>Create an Account</h2>
                        <p>Create account for our best service.</p>
                    </header>
                    <div className="box">
                        <form method="post" action="#">
                            <div className="row gtr-50 gtr-uniform">
                                <div className="col-6 col-12-mobilep">
                                    <input type="text" name="firstName" id="firstName" value="" placeholder="First Name" />
                                </div>
                                <div className="col-6 col-12-mobilep">
                                    <input type="text" name="lastName" id="lastName" value="" placeholder="Last Name" />
                                </div>
                                <div className="col-12">
                                    <input type="email" name="email" id="email" value="" placeholder="Email" />
                                </div>
                                <div className="col-12">
                                    <input type="text" name="password" id="password" value="" placeholder="Password" />
                                </div>
                                <div className="col-12">
                                    <ul className="actions special">
                                        <li><input type="submit" value="Create Account" /></li>
                                    </ul>
                                </div>
                            </div>
                        </form>
                        <div style={{ textAlign: "center" }}><Link to="/signup">Already have an account?</Link></div>
                    </div>
                </section>

                <footer id="footer">
                    <Link to="/home">Home </Link>  &nbsp; &nbsp;
                    <Link to="/FAQ">FAQ</Link> &nbsp; &nbsp;
                    <Link to="/about">About</Link> &nbsp; &nbsp;
                    <Link to="/contact">Contact</Link> &nbsp; &nbsp;
                    <Link to="/sign-up">Sign Up</Link>
                    <ul className="copyright">
                        <li>&copy; Singh Notaries. All rights reserved.</li>
                    </ul>
                </footer>
            </div>
        )
    }
}

export default Signup;
*/

import React from "react";
import { Link } from "react-router-dom";
import axios from "axios";

class Signup extends React.Component {
    componentDidMount() {
		window.scrollTo(0, 0);
	}
    constructor(props) {
        super(props);

        this.state = {
            name: "",
            email: "",
            password: "",
            confirmPassword: "",
            error: "",
        };
    }

    handleSubmit = async (event) => {
        event.preventDefault();

        try {
            const response = await axios.post("/signup", {
                name: this.state.name,
                email: this.state.email,
                password: this.state.password,
                confirmPassword: this.state.confirmPassword,
            });

            // Upon successful signup, redirect the user to the Login page.
            this.props.history.push("/login");
        } catch (error) {
            this.setState({ error: error.response.data.description });
        }
    };

    render() {
        return (
            <div id="page-wrapper">
                <section id="main" className="container medium">
                    <header>
                        <h2>Sign Up</h2>
                        <p>Singh Notaries</p>
                    </header>
                    <div className="box">
                        <form onSubmit={this.handleSubmit}>
                            <div className="row gtr-50 gtr-uniform">
                                <div className="col-12">
                                    <input
                                        type="text"
                                        name="name"
                                        id="name"
                                        value={this.state.name}
                                        placeholder="Full Name"
                                        onChange={(event) =>
                                            this.setState({
                                                name: event.target.value,
                                            })
                                        }
                                    />
                                </div>
                                <div className="col-12">
                                    <input
                                        type="email"
                                        name="email"
                                        id="email"
                                        value={this.state.email}
                                        placeholder="Email"
                                        onChange={(event) =>
                                            this.setState({
                                                email: event.target.value,
                                            })
                                        }
                                    />
                                </div>
                                <div className="col-12">
                                    <input
                                        type="password"
                                        name="password"
                                        id="password"
                                        value={this.state.password}
                                        placeholder="Password"
                                        onChange={(event) =>
                                            this.setState({
                                                password: event.target.value,
                                            })
                                        }
                                    />
                                </div>
                                {/* This is a multi-line comment in JSX
<div className="col-12">
    <input
        type="password"
        name="confirmPassword"
        id="confirmPassword"
        value={this.state.confirmPassword}
        placeholder="Confirm Password"
        onChange={(event) =>
            this.setState({
                confirmPassword: event.target.value,
            })
        }
    />
</div>
*/}
                                <div className="col-12">
                                    <ul className="actions special">
                                        <li>
                                            <input type="submit" value="Sign Up" />
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </form>
                        {this.state.error && (
                            <p className="error-message">{this.state.error}</p>
                        )}
                        <div style={{ textAlign: "center" }}>
                            <Link to="/login">Already have an account?</Link>
                        </div>
                    </div>
                </section>

                <footer id="footer">
                    <Link to="/home">Home </Link> &nbsp; &nbsp;
                    <Link to="/FAQ">FAQ</Link> &nbsp; &nbsp;
                    <Link to="/about">About</Link> &nbsp; &nbsp;
                    <Link to="/contact">Contact</Link> &nbsp; &nbsp;
                    <Link to="/login">Log In</Link>
                    <ul className="copyright">
                        <li>&copy; Singh Notaries. All rights reserved.</li>
                    </ul>
                </footer>
            </div>
        );
    }
}
export default Signup;
